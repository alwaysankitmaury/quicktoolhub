// src/blog/categories.js — Blog categories and which post belongs to which category.

export const BLOGCATS = [
  ["images", "Images and Photos", "Guides on compressing, resizing, converting and sizing pictures, with advice on choosing between JPG, PNG and WebP.", "Pictures are the heaviest part of most web pages and messages. These articles explain how image formats differ, how to shrink a photo without visible damage, and which sizes social platforms expect, so you can prepare images that look sharp and load quickly."],
  ["pdf-documents", "PDF and Documents", "Guides on merging, splitting and tidying PDF files and preparing clean documents for applications.", "Forms, applications and offices still run on PDF files. These articles show how to combine pages, remove or rotate them, and prepare a neat document pack, all without installing software or uploading private papers to a server."],
  ["video", "Video", "Guides on trimming, shrinking and reframing short videos in the browser.", "You do not need desktop editing software for every small video job. These articles cover trimming, compressing and reframing clips for sharing, and explain what to expect when a video is processed inside your browser."],
  ["ai-prompts", "AI and Prompts", "Guides on writing better AI prompts and understanding tokens and API costs.", "Clear prompts get better answers, and tokens decide what AI services cost. These articles explain how to give an AI useful instructions and how to estimate prompt size and running costs before you build or buy."],
  ["money-business", "Money and Business", "Guides on EMI, SIP, GST, discounts and profit margins.", "Loans, investments and prices all come down to a little arithmetic. These articles explain the maths behind EMI, SIP, GST and margins in plain language, with worked examples you can repeat with your own figures."],
  ["text-code-links", "Text, Code and Links", "Guides on text formatting, data formats and QR codes.", "Small formatting details make writing and data easier to read and use. These articles explain text case styles, JSON, Base64 and hashing, and how QR codes work, in terms that non-developers can follow."],
  ["privacy-security", "Privacy and Security", "Guides on keeping files and passwords safe online.", "Private documents and passwords deserve care. These articles explain why processing files in your browser reduces exposure, and how password generators and hashes help protect your accounts."]
];
export const BLOGCATBY = {};
BLOGCATS.forEach(function (c) { BLOGCATBY[c[0]] = c; });
export const BLOGCAT = {
  "compress-images-without-losing-quality": "images", "image-formats-jpg-png-webp-explained": "images", "social-media-image-video-sizes-reference": "images",
  "merge-split-organize-pdf-files": "pdf-documents", "how-to-prepare-a-clean-pdf-resume": "pdf-documents",
  "browser-video-editing-without-installing-software": "video", "how-to-compress-videos-without-ruining-quality": "video",
  "beginners-guide-to-writing-better-ai-prompts": "ai-prompts", "ai-tokens-explained-and-how-to-estimate-api-cost": "ai-prompts",
  "emi-vs-sip-understanding-the-math": "money-business", "gst-discounts-profit-margins-for-small-sellers": "money-business",
  "complete-guide-to-text-case-styles": "text-code-links", "json-base64-hashing-explained-for-non-developers": "text-code-links", "beginners-guide-to-qr-codes": "text-code-links",
  "why-browser-based-tools-are-safer-for-private-files": "privacy-security", "password-security-generators-hashes-explained": "privacy-security"
};
