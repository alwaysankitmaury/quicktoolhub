// src/blog/posts/index.js — LIST OF ALL BLOG POSTS (order = order on site).
// To add a new post: create a new file in this folder (copy any existing one), import it below and add it to BLOG.
import post_compress_images_without_losing_quality from "./compress-images-without-losing-quality.js";
import post_merge_split_organize_pdf_files from "./merge-split-organize-pdf-files.js";
import post_beginners_guide_to_writing_better_ai_prompts from "./beginners-guide-to-writing-better-ai-prompts.js";
import post_browser_video_editing_without_installing_software from "./browser-video-editing-without-installing-software.js";
import post_emi_vs_sip_understanding_the_math from "./emi-vs-sip-understanding-the-math.js";
import post_complete_guide_to_text_case_styles from "./complete-guide-to-text-case-styles.js";
import post_json_base64_hashing_explained_for_non_developers from "./json-base64-hashing-explained-for-non-developers.js";
import post_social_media_image_video_sizes_reference from "./social-media-image-video-sizes-reference.js";
import post_why_browser_based_tools_are_safer_for_private_files from "./why-browser-based-tools-are-safer-for-private-files.js";
import post_gst_discounts_profit_margins_for_small_sellers from "./gst-discounts-profit-margins-for-small-sellers.js";
import post_password_security_generators_hashes_explained from "./password-security-generators-hashes-explained.js";
import post_image_formats_jpg_png_webp_explained from "./image-formats-jpg-png-webp-explained.js";
import post_beginners_guide_to_qr_codes from "./beginners-guide-to-qr-codes.js";
import post_how_to_prepare_a_clean_pdf_resume from "./how-to-prepare-a-clean-pdf-resume.js";
import post_how_to_compress_videos_without_ruining_quality from "./how-to-compress-videos-without-ruining-quality.js";
import post_ai_tokens_explained_and_how_to_estimate_api_cost from "./ai-tokens-explained-and-how-to-estimate-api-cost.js";

export const BLOG = [
  post_compress_images_without_losing_quality,
  post_merge_split_organize_pdf_files,
  post_beginners_guide_to_writing_better_ai_prompts,
  post_browser_video_editing_without_installing_software,
  post_emi_vs_sip_understanding_the_math,
  post_complete_guide_to_text_case_styles,
  post_json_base64_hashing_explained_for_non_developers,
  post_social_media_image_video_sizes_reference,
  post_why_browser_based_tools_are_safer_for_private_files,
  post_gst_discounts_profit_margins_for_small_sellers,
  post_password_security_generators_hashes_explained,
  post_image_formats_jpg_png_webp_explained,
  post_beginners_guide_to_qr_codes,
  post_how_to_prepare_a_clean_pdf_resume,
  post_how_to_compress_videos_without_ruining_quality,
  post_ai_tokens_explained_and_how_to_estimate_api_cost,
];
