// src/pages/index.js — PAGES map: URL path -> [title, description, body]. Add new static pages here.
import { ABOUT } from "./about.js";
import { CONTACT } from "./contact.js";
import { DISCLAIMER } from "./disclaimer.js";
import { EDITORIAL } from "./editorial.js";
import { HOWTO } from "./how-to-use.js";
import { PRIVACY } from "./privacy.js";
import { TERMS } from "./terms.js";

export const PAGES = {
  "/about": ["About Us", "Learn about ToolsNest, a free collection of online photo, video, PDF, text and developer tools that run in your browser.", ABOUT],
  "/contact": ["Contact Us", "Contact ToolsNest for support, feedback, tool requests or business enquiries.", CONTACT],
  "/privacy-policy": ["Privacy Policy", "How ToolsNest handles your data, cookies and Google AdSense advertising.", PRIVACY],
  "/terms": ["Terms and Conditions", "Terms and conditions for using the ToolsNest website and tools.", TERMS],
  "/disclaimer": ["Disclaimer", "Disclaimer for the tools, calculators and information on ToolsNest.", DISCLAIMER]
};
PAGES["/how-to-use"] = ["How to Use", "Step-by-step guides, features and FAQs for ToolsNest's free online photo, video, PDF, AI prompt, text, developer and calculator tools.", HOWTO];
PAGES["/editorial-policy"] = ["Editorial Policy", "How ToolsNest builds free online tools, writes guides, checks accuracy, handles advertising and accepts corrections.", EDITORIAL];
